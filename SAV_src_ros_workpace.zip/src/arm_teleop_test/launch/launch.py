import launch
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        launch.actions.ExecuteProcess(
            cmd=["xterm", "-hold", "-fa", "Fixed", "-fs", "12", "-geometry", "150x20", "-e", "ros2", "launch", "fanuc_ros2_driver","fanuc_interface.launch.py", "robot_ip:='192.168.1.1'","robot_type:=crx10ia","license_path:='/home/jrluser/Desktop/fanuc_workspace/license.data'"],
            output="screen",
        ),
        launch.actions.ExecuteProcess(
            cmd=["xterm", "-hold", "-fa", "Fixed", "-fs", "12", "-geometry", "60x20","-e", "ros2", "launch", "fanuc_ros2_driver", "test_fanuc.launch.py", "robot_type:=crx10ia"],
            output="screen",
        ),
        launch.actions.ExecuteProcess(
            cmd=["xterm", "-hold", "-fa", "Fixed", "-fs", "12", "-geometry", "120x30","-e", "ros2", "run", "arm_teleop_test", "arm_teleop_node"],
            output="screen",
        ),
    ])