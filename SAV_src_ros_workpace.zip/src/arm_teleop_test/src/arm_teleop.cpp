#include "rclcpp/rclcpp.hpp"
#include "rclcpp_action/rclcpp_action.hpp"
#include "control_msgs/action/follow_joint_trajectory.hpp"
#include <string>
#include <math.h>
#include <chrono>
#include <termios.h>
#include "conio.h"

using namespace std::chrono_literals;
using namespace std::placeholders;

void flush_input_buffer() {
    struct termios term;
    tcgetattr(STDIN_FILENO, &term);
    while (_kbhit()) {
        char c = _getche();
    }
    tcsetattr(STDIN_FILENO, TCSANOW, &term);
}

class JointTrajectoryActionClient : public rclcpp::Node
{
public:
    using FollowJointTrajectoryAction = control_msgs::action::FollowJointTrajectory;
    using FollowJointTrajectoryGoalHandle = rclcpp_action::ClientGoalHandle<FollowJointTrajectoryAction>;
    std::string action_server = "/arm_controller/follow_joint_trajectory";

    JointTrajectoryActionClient(): Node("arm_teleop_node")
    {
        //create client
        this->action_client_ = rclcpp_action::create_client<FollowJointTrajectoryAction>(this,action_server.c_str());

        // Wait for the action server to be available
        RCLCPP_INFO(this->get_logger(), "Searching for Action server :\n%s\n",action_server.c_str());
        /*while (!action_client_->wait_for_action_server(std::chrono::seconds(1)))
        {
            RCLCPP_ERROR(this->get_logger(), "Action server not available after waiting...");
        }*/
        RCLCPP_INFO(this->get_logger(), "Action server connected");
        // Use a timer to get key press every second
        timer_ = create_wall_timer(dt,std::bind(&JointTrajectoryActionClient::timer_callback, this));
        //instructions
        show_msg();
    
    }

private:
    std::chrono::milliseconds dt = 10ms;
    int key_code = 0;
    double cmd_vect[6] = {0.0, 0.0, 0.0, 0.7, 0.0, -0.7};
    int reso = 50;
    double angle_incr = 2*M_PI/reso;

    //TELEOPERATION Functions
    void show_msg(){
        printf("\nKEYBOARD CONTROLS:\n\n");
        printf("Q/A: Joint1\n");
        printf("W/S: Joint2\n");
        printf("E/D: Joint3\n");
        printf("R/F: Joint4\n");
        printf("T/G: Joint5\n");
        printf("Y/H: Joint6\n");
    }

    void check_keyboard(){
    if ( _kbhit() ){
        this->key_code = _getche();
        flush_input_buffer(); //empty tampon memory
    }
    else{
        this->key_code = -1;
    }
    /*stringstream strs;
    strs << this->key_code;
    string temp_str = strs.str();
    char* char_type = (char*) temp_str.c_str();
    printf(char_type);*/
    }

    void timer_callback()
    {   

        double new_cmd_vect[6];
        std::copy(cmd_vect, cmd_vect + 6, new_cmd_vect);

        check_keyboard();
        switch (this->key_code)
        {
        case 113: //q
            new_cmd_vect[0] += angle_incr;
            break;
        case 119: //w
            new_cmd_vect[1] += angle_incr;
            break;
        case 101: //e
            new_cmd_vect[2] += angle_incr;
            break;
        case 114: //r
            new_cmd_vect[3] += angle_incr;
            break;
        case 116: //t
            new_cmd_vect[4] += angle_incr;
            break;
        case 121: //y
            new_cmd_vect[5] += angle_incr;
            break;
        case 97: //a
            new_cmd_vect[0] -= angle_incr;
            break;
        case 115: //s
            new_cmd_vect[1] -= angle_incr;        
            break;
        case 100: //d
            new_cmd_vect[2] -= angle_incr;
            break;
        case 102: //f
            new_cmd_vect[3] -= angle_incr;
            break;
        case 103: //g
            new_cmd_vect[4] -= angle_incr;
            break;
        case 104: //h
            new_cmd_vect[5] -= angle_incr;
            break;
        }

        bool diff_cmd = false;

        for (int i =0;i<6;i++){
            if(new_cmd_vect[i]>M_PI){
                new_cmd_vect[i] = new_cmd_vect[i]-2*M_PI;
            }
            else if(new_cmd_vect[i]<=-M_PI){
                new_cmd_vect[i] = new_cmd_vect[i]+2*M_PI;
            }

            if(abs(cmd_vect[i]-new_cmd_vect[i])>0.001){
                diff_cmd = true;
            }
        }

        //END OF MAIN

        if (diff_cmd){
            std::copy(new_cmd_vect, new_cmd_vect + 6, cmd_vect);
            printf("\nNew_command: {%.2f,%.2f,%.2f,%.2f,%.2f,%.2f}",cmd_vect[0],cmd_vect[1],cmd_vect[2],cmd_vect[3],cmd_vect[4],cmd_vect[5]);
            //We send an action if needed
            sendJointTrajectoryGoal();
        }

    }

    //ACTION FUNCTIONS

    void sendJointTrajectoryGoal()
    {
        // Create a FollowJointTrajectory goal
        auto goal_msg = FollowJointTrajectoryAction::Goal();
        goal_msg.trajectory.header.stamp = now();
        goal_msg.trajectory.header.frame_id = "base_link";
        goal_msg.trajectory.joint_names = {"joint_1", "joint_2", "joint_3", "joint_4", "joint_5", "joint_6"};

        auto point = goal_msg.trajectory.points.emplace_back();
        point.positions.assign(cmd_vect, cmd_vect + 6);
        point.velocities = {0.1, 0.1, 0.1, 0.1, 0.1, 0.1};
        point.accelerations = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
        //point.time_from_start = rclcpp::Duration(2, 0); //we want the robot to execute as soon as possible

        // Send the action goal
        auto send_goal_options = rclcpp_action::Client<FollowJointTrajectoryAction>::SendGoalOptions();
        send_goal_options.goal_response_callback =std::bind(&JointTrajectoryActionClient::goal_response_callback, this, _1);
        //send_goal_options.feedback_callback =std::bind(&JointTrajectoryActionClient::feedback_callback, this, _1, _2);
        send_goal_options.result_callback =std::bind(&JointTrajectoryActionClient::result_callback, this, _1);

        auto goal_handle_future = action_client_->async_send_goal(goal_msg, send_goal_options);
        
    }

    void goal_response_callback(const FollowJointTrajectoryGoalHandle::SharedPtr & goal_handle)
    {
        if (!goal_handle)
        {
            RCLCPP_ERROR(this->get_logger(), "Goal was rejected by the action server");
        }
        else {
            RCLCPP_INFO(this->get_logger(), "Goal accepted by server, waiting for result");
        }
    }

    void result_callback(const FollowJointTrajectoryGoalHandle::WrappedResult &result)
    {
        switch (result.code)
        {
        case rclcpp_action::ResultCode::SUCCEEDED:
            RCLCPP_INFO(this->get_logger(), "Goal succeeded");
            break;
        default:
            RCLCPP_ERROR(this->get_logger(), "Goal failed with result code %d", static_cast<int>(result.code));
            break;
        }
    }

    rclcpp_action::Client<FollowJointTrajectoryAction>::SharedPtr action_client_;
    rclcpp::TimerBase::SharedPtr timer_;
};


int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<JointTrajectoryActionClient>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
