/*
 * Copyright(c) 2024, RT Coorp.
 */
#pragma once
#include <memory>
#include <string>
#include <iostream>

#include <rclcpp/rclcpp.hpp>
#include <lifecycle_msgs/srv/change_state.hpp>
#include <lifecycle_msgs/srv/get_state.hpp>
#include <lifecycle_msgs/srv/get_available_states.hpp>
#include <lifecycle_msgs/srv/get_available_transitions.hpp>
#include <lifecycle_msgs/msg/state.hpp>

#include <sensor_msgs/msg/joy.hpp>
#include <geometry_msgs/msg/twist.hpp>

namespace joy_twist
{
/*
 *
 */
class JoyTwist: public rclcpp::Node
{
public:
  JoyTwist();
  ~JoyTwist(void);

private:
  void create_lifecycleclient(std::string name);
  int get_state() ;
  void change_state(int id);
  void callback(const sensor_msgs::msg::Joy & msg) ;
  void print_joy_data(const sensor_msgs::msg::Joy & msg) ;
  void process_button(const sensor_msgs::msg::Joy & msg) ;

  //void cb_get_state(rclcpp::Client<lifecycle_msgs::srv::GetState>::SharedFuture future);
  /*
   *
   */
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr pub_twist_;
  rclcpp::Subscription<sensor_msgs::msg::Joy>::SharedPtr sub_joy_;
  rclcpp::Client<lifecycle_msgs::srv::GetState>::SharedPtr get_state_client_;
  rclcpp::Client<lifecycle_msgs::srv::ChangeState>::SharedPtr change_state_client_;

  /*
   *
   */
  bool debug;
  int x_axis;
  int y_axis;
  int w_axis;
  float v_scale;
  float w_scale;

  int configure_button;
  int activate_button;
  int deactivate_button;
  int cleanup_button;
  int shutdown_button;
  std::string robot_name;
};

}


