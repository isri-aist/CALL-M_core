/*
 * Copyright(c) 2024, RT Coorp.
 */
#include <joy_twist/joy_twist.hpp>

/*
 *  M A I N
 */
int
main(int argc, char** argv)
{
  rclcpp::init(argc, argv);
  rclcpp::executors::MultiThreadedExecutor exec;
  std::shared_ptr<joy_twist::JoyTwist> node =
	  std::make_shared<joy_twist::JoyTwist>();
  exec.add_node(node->get_node_base_interface());
  exec.spin();
  rclcpp::shutdown();
}
