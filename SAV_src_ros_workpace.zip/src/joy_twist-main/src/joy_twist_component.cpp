/**
 * Copyright(C) 2024, RT Coorp.
 */
#include <joy_twist/joy_twist.hpp>

using namespace std::chrono_literals;

constexpr auto JOY_TWIST_NAME="joy_twist_node";
constexpr auto TRIORB_NAME="/triorb";

constexpr auto CMD_VEL = "cmd_vel";
constexpr auto JOY = "joy";
constexpr auto X_AXIS = 1;
constexpr auto Y_AXIS = 0;
constexpr auto W_AXIS = 3;
constexpr auto CONFIG_BTN = 0;
constexpr auto ACT_BTN = 1;
constexpr auto DEACT_BTN = 2;
constexpr auto CLEAN_BTN = 3;
constexpr auto SHUTDOWN_BTN = 4;

using std::placeholders::_1;

namespace joy_twist
{
/**
 * Constructor
 */
JoyTwist::JoyTwist() 
    : Node(JOY_TWIST_NAME),
     debug(false), x_axis(X_AXIS), y_axis(Y_AXIS), w_axis(W_AXIS),
     v_scale(0.2), w_scale(0.5), configure_button(CONFIG_BTN),
     activate_button(ACT_BTN),deactivate_button(DEACT_BTN),
     cleanup_button(CLEAN_BTN),shutdown_button(SHUTDOWN_BTN), robot_name(TRIORB_NAME) {
    
    this->declare_parameter("x_axis", X_AXIS);
    this->declare_parameter("y_axis", Y_AXIS);
    this->declare_parameter("w_axis", W_AXIS);
    this->declare_parameter("v_scale", 0.2);
    this->declare_parameter("w_scale", 0.5);
    this->declare_parameter("configure_button", CONFIG_BTN);
    this->declare_parameter("activate_button", ACT_BTN);
    this->declare_parameter("deactivate_button", DEACT_BTN);
    this->declare_parameter("cleanup_button", CLEAN_BTN);
    this->declare_parameter("shutdown_button", SHUTDOWN_BTN);
    this->declare_parameter("robot_name", TRIORB_NAME);

    this->declare_parameter("debug", false);

    debug = this->get_parameter("debug").as_bool();
    x_axis = this->get_parameter("x_axis").as_int();
    y_axis = this->get_parameter("y_axis").as_int();
    w_axis = this->get_parameter("w_axis").as_int();
    v_scale = this->get_parameter("v_scale").as_double();
    w_scale = this->get_parameter("w_scale").as_double();
    configure_button = this->get_parameter("configure_button").as_int();
    activate_button = this->get_parameter("activate_button").as_int();
    deactivate_button = this->get_parameter("deactivate_button").as_int();
    cleanup_button = this->get_parameter("cleanup_button").as_int();
    shutdown_button = this->get_parameter("shutdown_button").as_int();
    robot_name = this->get_parameter("robot_name").as_string();

    pub_twist_ = this->create_publisher<geometry_msgs::msg::Twist>(CMD_VEL, 10);

    auto my_callback_group = create_callback_group(rclcpp::CallbackGroupType::MutuallyExclusive);

    rclcpp::SubscriptionOptions options;
    options.callback_group = my_callback_group;
    sub_joy_ = this->create_subscription<sensor_msgs::msg::Joy>(JOY, 10,
                     std::bind(&JoyTwist::callback, this, _1), options);
    create_lifecycleclient(robot_name);
    RCLCPP_INFO(this->get_logger(), "Start JoyTwist");
}

/**
 * Deconstructor
 */
JoyTwist::~JoyTwist(void) {

}

/**
 * Create ROS 2 service client for lifecycle transition
 */
void
JoyTwist::create_lifecycleclient(std::string name) {
    auto service_callback_group = nullptr;
    std::string ch_state = name+"/change_state";
    this->change_state_client_ = this->create_client<lifecycle_msgs::srv::ChangeState>(ch_state,
        rmw_qos_profile_services_default,
        service_callback_group);

    while(!change_state_client_->wait_for_service(5s)){
    if(!rclcpp::ok()){
      RCLCPP_ERROR(this->get_logger(), "Interrupted while waiting for the service.");
      return ;
    }
    RCLCPP_INFO(this->get_logger(), "waiting for service...");
  }
    std::string get_state = name+"/get_state";
    this->get_state_client_ = this->create_client<lifecycle_msgs::srv::GetState>(get_state,
        rmw_qos_profile_services_default,
        service_callback_group);
    return;
}

/**
 *  ROS 2 service call to get the lifecycle node
 *     Return: Lifecycle state ID
 */
int
JoyTwist::get_state() {
    if (!this->get_state_client_->service_is_ready()) {
        return -1;
    }
    auto request = std::make_shared<lifecycle_msgs::srv::GetState::Request>();
    auto result = this->get_state_client_->async_send_request(request);

    if(result.wait_for(1s) == std::future_status::ready){
        int id = result.get()->current_state.id;
        return id;
    }else{
        RCLCPP_ERROR(rclcpp::get_logger("rclcpp"), "Failed to call service");
    }
    return -1;
}

/**
 *  ROS 2 service call to change the lifecycle node's state
 */
void
JoyTwist::change_state(int id) {
    if (!this->change_state_client_->service_is_ready()) {
        return;
    }
    auto request = std::make_shared<lifecycle_msgs::srv::ChangeState::Request>();
    request->transition.id=id;
    auto result = this->change_state_client_->async_send_request(request);
    return;
}

/**
 * Callback function for the topic, /joy
 */
void
JoyTwist::callback(const sensor_msgs::msg::Joy & msg)  {
    process_button(msg);

    auto twist = geometry_msgs::msg::Twist();
    twist.linear.x = msg.axes[x_axis] * v_scale;
    twist.linear.y = msg.axes[y_axis] * v_scale;
    twist.angular.z = msg.axes[w_axis] * w_scale;
    pub_twist_->publish(twist);
    if (debug) {
        print_joy_data(msg);
    }

    return;
}

/**
 * Display /joy message. (for debug)
 */
void
JoyTwist::print_joy_data(const sensor_msgs::msg::Joy & msg)  {
    std::cout << "Axis: ";
    for (auto it = std::cbegin(msg.axes); it != std::cend(msg.axes); it++) {
        std::cout << *it << ' ';
    }
    std::cout << std::endl << "Button: ";
    for (auto it = std::cbegin(msg.buttons); it != std::cend(msg.buttons); it++) {
        std::cout << *it << ' ';
    }
    std::cout << std::endl;
    return;
}

/**
 *  Callback function the buttons
 */
void
JoyTwist::process_button(const sensor_msgs::msg::Joy & msg)  {
    int stat_id;
    if(configure_button >= 0 && msg.buttons[configure_button] == 1){
        stat_id = get_state();
        if (stat_id == lifecycle_msgs::msg::State::PRIMARY_STATE_UNCONFIGURED) {
            change_state(lifecycle_msgs::msg::Transition::TRANSITION_CONFIGURE); 
            std::cout << "configure" << std::endl;
            return;        
        }

    }else if (activate_button >= 0 && msg.buttons[activate_button] == 1){
        stat_id=get_state();
        if (stat_id == lifecycle_msgs::msg::State::PRIMARY_STATE_INACTIVE) {
            change_state(lifecycle_msgs::msg::Transition::TRANSITION_ACTIVATE); 
            std::cout << "activate" << std::endl;
        } 

    }else if (deactivate_button >= 0 && msg.buttons[deactivate_button] == 1){
        stat_id=get_state();
        if (stat_id == lifecycle_msgs::msg::State::PRIMARY_STATE_ACTIVE) {
            change_state(lifecycle_msgs::msg::Transition::TRANSITION_DEACTIVATE); 
            std::cout << "deactivate" << std::endl;
        }

    }else if (cleanup_button >= 0 && msg.buttons[cleanup_button] == 1){
        stat_id=get_state();
        if (stat_id == lifecycle_msgs::msg::State::PRIMARY_STATE_INACTIVE) {
            change_state(lifecycle_msgs::msg::Transition::TRANSITION_CLEANUP); 
            std::cout << "cleanup" << std::endl;
        }

    }else if (shutdown_button>=0 && msg.buttons[shutdown_button] == 1){
        stat_id=get_state();
        switch (stat_id) {
            case lifecycle_msgs::msg::State::PRIMARY_STATE_UNCONFIGURED:
                change_state(lifecycle_msgs::msg::Transition::TRANSITION_UNCONFIGURED_SHUTDOWN); 
                std::cout << "shutdown unconfigured" << std::endl;
                break;
            case lifecycle_msgs::msg::State::PRIMARY_STATE_INACTIVE:
                change_state(lifecycle_msgs::msg::Transition::TRANSITION_INACTIVE_SHUTDOWN); 
                std::cout << "shutdown inactive" << std::endl;
                break;
            case lifecycle_msgs::msg::State::PRIMARY_STATE_ACTIVE:
                change_state(lifecycle_msgs::msg::Transition::TRANSITION_ACTIVE_SHUTDOWN); 
                std::cout << "shutdown active" << std::endl;
                break;

            case lifecycle_msgs::msg::State::PRIMARY_STATE_FINALIZED:
                std::cout << "shutdown finalized" << std::endl;
                rclcpp::shutdown();
                break;

            default:
                rclcpp::shutdown();
                return;
        }
    }
    
    RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "Stat_id=%d",stat_id);
    
    return;
}

}
