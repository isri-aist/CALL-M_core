/*
  kinema.cpp
  created 21/12/18
 */

#include <stdio.h>
#include <math.h>
#include "func.h"
#include "kinema.h"

#include "kin_START21MOVab.txt"

