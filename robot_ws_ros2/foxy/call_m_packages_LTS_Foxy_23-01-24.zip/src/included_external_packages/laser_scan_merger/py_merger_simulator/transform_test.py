import numpy as np

from tools import *
import random

#repere
class bench():
    def __init__(self,O,tetha):
        self.O = O
        self.tetha = tetha
        self.R = rotation_matrix(tetha)
        self.x = self.R@np.array([[1],[0]])
        self.y = self.R@np.array([[0],[1]])

    def draw(self,color):
        draw_disk(ax, self.O, 0.1, color)
        draw_line(self.O, self.x+self.O,'red')
        draw_line(self.O, self.y+self.O, 'green')

    def update(self,tetha):
        self.tetha = tetha
        self.R = rotation_matrix(tetha)
        self.x = self.R@np.array([[1],[0]])
        self.y = self.R@np.array([[0],[1]])

#INPUTS
tetha1 = to_radian(0) #angle between L0=base_link and L1=lidar (L0=>L1), angle in base_link frame
C1 = np.array([[0],[-1]]) #in L1 frame, point detected by lidar

#parameters
pos1 = np.array([[0.18920],[0.18920]]) #position in base_link frame of lidar1
L0 =bench(np.array([[0],[0]]) ,0)
L1 =bench(pos1,tetha1)
off_pos = pos1 #new_frame => lidar

"""
We want C0 = coordinate of C1 in C0 frame (rotated of -tetha compared to L1)
"""
#static version
def angle_to_index(alpha,resolution):
    alpha = alpha%(2*pi)
    if alpha<0:
        alpha+=2*pi
    return int(round(alpha*resolution/(2*pi)))

def index_to_angle(ind, resolution):
    return ind*2*pi/resolution

def get_pos(alpha,val,x_off,y_off):
    x = val*cos(alpha)+x_off
    y = val*sin(alpha)+y_off
    return np.array([[x],[y]])

def map_angle(alpha):
    new_alpha=alpha
    if alpha<0:
        new_alpha=alpha+2*pi
    if alpha==2*pi:
        new_alpha=0
    return new_alpha

ax=init_figure(-2,2,-2,2)

datas = [inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,1.16103,1.15294,1.1189,1.12998,1.1025,1.07435,1.05121,1.04302,1.03192,1.00856,0.996883,0.988041,0.968997,0.974625,0.969551,0.961777,0.936009,0.921814,0.93359,0.908107,0.918388,0.896148,0.908994,0.891058,0.88116,0.878184,0.860941,0.84955,0.848381,0.851187,0.831912,0.859746,0.835288,0.829216,0.842253,0.841211,0.8347,0.833951,0.809219,0.825684,0.806995,0.808073,0.816634,0.830137,0.817698,0.821397,0.81611,0.810526,0.801363,0.816568,0.800959,0.834437,0.823118,0.832032,0.821836,0.821376,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,1.58397,1.56221,1.56362,1.53835,1.51941,1.51519,1.50359,1.47495,1.44794,1.45873,1.43932,1.42187,1.42187,1.4072,1.39211,1.39004,1.37902,1.35909,1.36923,1.33544,1.3509,1.34653,1.3673,1.32142,1.34572,1.34262,1.31218,1.32987,1.32739,1.31103,1.32009,1.31353,1.31024,1.31482,1.33472,1.32004,1.31547,1.31704,1.31036,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,1.33501,1.27145,1.22583,1.19677,1.14866,1.14265,1.1457,1.11942,1.10995,1.09419,1.0746,1.0655,1.09504,1.05803,1.06637,1.07526,1.06509,1.05066,1.04248,1.06768,1.07986,1.08153,1.08762,1.10633,1.10919,1.11304,1.15391,1.16429,1.19033,1.2227,1.26376,1.33893,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf,inf]
resolution = len(datas)
L1.update(-2.356194)
for ind in range(len(datas)):
    iangle = index_to_angle(ind,resolution)
    ival= datas[ind]
    if ival!=inf:
        init_pos = get_pos(iangle,ival,0,0)
        ix,iy = init_pos.flatten()

        # transform to have C1 in base_link frame
        C0 = rotation_matrix(L1.tetha) @ init_pos  # what would detect the lidar if it was not rotated
        nx,ny = C0.flatten()
        C0 = off_pos + C0  # translation to base_link frame
        nx2, ny2 = C0.flatten()

        nval = norm(C0)
        nangle = map_angle(arctan2(ny2,nx2))

        nindex = angle_to_index(nangle,resolution)

        #clear(ax)
        # draw world
        L0.draw('black')
        L1.draw('gray')
        global_C1 = (L1.R @ init_pos) + L1.O  # in space
        draw_disk(ax, global_C1, 0.015, 'green')
        #draw_line(L1.O, global_C1, 'green')

        # draw results
        global_C0 = (L0.R @ C0) + L0.O  # in space
        draw_disk(ax, global_C0, 0.01, 'orange')
        #draw_line(L0.O, global_C0, 'orange')

        draw_line(global_C0, global_C1, 'red')  # error line, these points should be the same

        #print data
        #print("\r" + " " * 1500, end='   ')
        print("index= {}, iangle={}, ival={}, ix={}, iy={}, nx={}, ny={}, nx2={}, ny2={}, nval={}, nangle={}, nindex={}".format(ind,iangle,ival,ix,iy,nx,ny,nx2,ny2,nval,nangle,nindex))

pause(100)

#dynamic version

"""dt = 0.05
simu_speed=4

ax=init_figure(-5,5,-5,5)
for t in np.arange(0,100,dt):
    init_pos = C1 + np.array([[2*cos(t/2)],[2*sin(t/2)]])
    new_tetha = (0.1*t)%2*pi #-2.356194
    L1.update(new_tetha)

    #transform to have C1 in base_link frame
    C0 = rotation_matrix(L1.tetha) @ init_pos  # what would detect the lidar if it was not rotated
    C0 = off_pos + C0 #translation to base_link frame


    clear(ax)
    #draw world
    L0.draw('black')
    L1.draw('gray')
    global_C1 = (L1.R @ init_pos) + L1.O  # in space
    draw_disk(ax, global_C1, 0.15, 'green')
    draw_line(L1.O, global_C1, 'green')

    #draw results
    global_C0 = (L0.R@C0) + L0.O #in space
    draw_disk(ax, global_C0, 0.1, 'orange')
    draw_line(L0.O, global_C0,'orange')

    draw_line(global_C0, global_C1, 'red') #error line, these points should be the same

    #print data
    #print("\r" + " " * 1500, end='   ')
    wanted_vect = global_C1-L0.O
    curr_vect = global_C0-L0.O
    len_error = norm(wanted_vect)-norm(curr_vect)
    angle_error = sawtooth(arctan2(wanted_vect[1,0],wanted_vect[0,0]) - arctan2(curr_vect[1,0],curr_vect[0,0]))
    print("\rLength error: "+str(round(len_error,4)),end='   ')
    print("Angle error: " + str(round(to_degree(angle_error), 4)), end='   ')
    print("Tetha1: " + str(round(to_degree(sawtooth(L1.tetha)), 4)), end='   ')

    time.sleep(dt/simu_speed)"""